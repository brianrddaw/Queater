<?php

namespace App\Http\Controllers;

class CashController extends Controller
{
    public function index()
    {
        return view('cash-views.cash');
    }
}
