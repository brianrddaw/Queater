<div>
    <!-- Life is available only in the present moment. - Thich Nhat Hanh -->
</div><?php /**PATH C:\Users\Programación\Desktop\PROYECTO FINAL\resources\views\components\user-cart.blade.php ENDPATH**/ ?>