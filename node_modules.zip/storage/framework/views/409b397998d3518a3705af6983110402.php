<?php $__env->startSection('title', 'User'); ?>
<?php $__env->startSection('content'); ?>
    <section class="flex flex-col items-center">

        <h1>pepe feliz</h1>

        <button><a href="/printTicket/<?php echo e($orderId); ?>">Imprimir ticket</button>
            <button><a href="/">Volver al menu</button>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.html-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Programación\Desktop\PROYECTO FINAL\resources\views/user-views/user-payments/success.blade.php ENDPATH**/ ?>